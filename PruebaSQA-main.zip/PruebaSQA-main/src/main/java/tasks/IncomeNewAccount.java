package tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.thucydides.core.annotations.Step;

import static userinterfaces.RegisterClientUserInterface.*;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class IncomeNewAccount implements Task {

    public static Performable incomeNewAccount(){
        return instrumented(IncomeNewAccount.class);
    }

    @Override
    @Step("{0} ingresa a la opcion crear cuenta")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                WaitUntil.the(BTN_USER, WebElementStateMatchers.isClickable()),
                Click.on(BTN_USER),
                WaitUntil.the(BTN_NEW_ACCOUNT, WebElementStateMatchers.isVisible()),
                WaitUntil.the(BTN_NEW_ACCOUNT, WebElementStateMatchers.isClickable()),
                Click.on(BTN_NEW_ACCOUNT)
        );

    }

}
