package tasks;

import Enums.KeysRegisterClient;
import net.serenitybdd.core.steps.Instrumented;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import static userinterfaces.RegisterClientUserInterface.*;

import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.SelectFromOptions;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.thucydides.core.annotations.Step;
import utilitis.Utils;

import java.util.List;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class CreateAccount implements Task {

    private final List<String> data;

    public CreateAccount(List<String> data){
        this.data = data;
    }

    public static Performable createAccount(List<String> data){
        return Instrumented.instanceOf(CreateAccount.class).withProperties(data);
    }

    @Override
    @Step("{0} diligencia los datos personales para crear la cuenta")
    public <T extends Actor> void performAs(T actor) {

        String name = Utils.nameGenerate();
        String lastname = Utils.lastNameGenerate();
        String username = name.concat(lastname);
        actor.remember(KeysRegisterClient.KEY1.value(), username);

        actor.attemptsTo(
                WaitUntil.the(INPUT_USERNAME, WebElementStateMatchers.isVisible()),
                Enter.theValue(username).into(INPUT_USERNAME),
                Enter.theValue(Utils.emailGenerate()).into(INPUT_EMAIL),
                Enter.theValue(Utils.passwordGenerate()).into(INPUT_PASSWORD),
                Enter.theValue(Utils.passwordGenerate()).into(INPUT_CONFIRM_PASSWORD),
                Enter.theValue(name).into(INPUT_FIRST_NAME),
                Enter.theValue(lastname).into(INPUT_LAST_NAME),
                Enter.theValue(Utils.phoneNumberGenerate()).into(INPUT_PHONE_NUMBER),
                Scroll.to(SELECT_COUNTRY),
                SelectFromOptions.byVisibleText(data.get(0)).from(SELECT_COUNTRY),
                Enter.theValue(data.get(1)).into(INPUT_CITY),
                Enter.theValue(Utils.addressGenerate()).into(INPUT_ADDRESS),
                //Enter.theValue(data.get(1)).into(INPUT_STATE),
                Enter.theValue(Utils.postalGenerate()).into(INPUT_POSTAL_CODE),
                Click.on(SELECT_AGREE_TYC),
                Click.on(BTN_REGISTER),
                WaitUntil.the(VALIDATE_CREATE_ACCOUNT, WebElementStateMatchers.isVisible())
        );

    }
}
