package Enums;

public enum KeysRegisterClient {

    KEY1("UserName");

    private final String value;
    KeysRegisterClient(String value) {this.value = value;}
    public String value() {
        return value;
    }

}
