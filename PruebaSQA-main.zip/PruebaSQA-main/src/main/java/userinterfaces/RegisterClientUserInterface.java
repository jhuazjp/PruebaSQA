package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class RegisterClientUserInterface {

    public static final Target BTN_USER = Target.the("user").
            located(By.id("menuUser"));
    public static final Target BTN_NEW_ACCOUNT = Target.the("new account").
            located(By.xpath("//*[@class='create-new-account ng-scope']"));
    public static final Target INPUT_USERNAME = Target.the("username").
            located(By.xpath("//input[@name='usernameRegisterPage']"));
    public static final Target INPUT_EMAIL = Target.the("username").
            located(By.xpath("//input[@name='emailRegisterPage']"));
    public static final Target INPUT_PASSWORD = Target.the("password").
            located(By.xpath("//input[@name='passwordRegisterPage']"));
    public static final Target INPUT_CONFIRM_PASSWORD = Target.the("confirm password").
            located(By.xpath("//input[@name='confirm_passwordRegisterPage']"));
    public static final Target INPUT_FIRST_NAME = Target.the("first name").
            located(By.xpath("//input[@name='first_nameRegisterPage']"));
    public static final Target INPUT_LAST_NAME = Target.the("last name").
            located(By.xpath("//input[@name='last_nameRegisterPage']"));
    public static final Target INPUT_PHONE_NUMBER = Target.the("phone number").
            located(By.xpath("//input[@name='phone_numberRegisterPage']"));
    public static final Target SELECT_COUNTRY = Target.the("country").
            located(By.xpath("//select[@name='countryListboxRegisterPage']"));
    public static final Target INPUT_CITY = Target.the("city").
            located(By.xpath("//input[@name='cityRegisterPage']"));
    public static final Target INPUT_ADDRESS = Target.the("address").
            located(By.xpath("//input[@name='addressRegisterPage']"));
    public static final Target INPUT_STATE = Target.the("state").
            located(By.xpath("//input[@name='state_/_province_/_regionRegisterPage']"));
    public static final Target INPUT_POSTAL_CODE = Target.the("postal code").
            located(By.xpath("//input[@name='postal_codeRegisterPage']"));
    public static final Target SELECT_AGREE_TYC = Target.the("agree t y c").
            located(By.xpath("//input[@name='i_agree']"));
    public static final Target BTN_REGISTER = Target.the("register").
            located(By.id("register_btnundefined"));
    public static final Target VALIDATE_CREATE_ACCOUNT = Target.the("validar cliente creado").
            located(By.xpath("//*[@id='menuUserLink']//span"));
    public static final Target ICON_ACCOUNT = Target.the("icono de cuenta").
            located(By.xpath("//*[@id='menuUserLink']/a"));

}
