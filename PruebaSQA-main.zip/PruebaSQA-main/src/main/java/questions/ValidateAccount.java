package questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.questions.targets.TheTarget;
import net.serenitybdd.screenplay.targets.Target;
import userinterfaces.RegisterClientUserInterface;

public class ValidateAccount implements Question<String>{

    private final Target target;

    public ValidateAccount(Target objeto) {
        this.target = objeto;
    }

    public static Question<String> visibles(Target objeto) {
        return new ValidateAccount(objeto);
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(target).answeredBy(actor);
    }

}
