package utilitis;

import com.github.javafaker.Faker;

public class Utils {

    public static String nameGenerate(){
        return new Faker().name().firstName();
    }

    public static String lastNameGenerate(){
        return new Faker().name().lastName();
    }

    public static String passwordGenerate(){
        return "FoaQ2381*!";
    }

    public static String emailGenerate(){
        return new Faker().internet().emailAddress();
    }

    public static String phoneNumberGenerate(){
        return new Faker().phoneNumber().cellPhone();
    }

    public static String addressGenerate(){
        return new Faker().address().streetAddress();
    }

    public static String postalGenerate(){
        return String.valueOf(new Faker().number().numberBetween(100000,999999));
    }

}
