package stepdefinitions;

import Enums.KeysRegisterClient;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import questions.ValidateAccount;
import tasks.CreateAccount;
import tasks.IncomeNewAccount;
import userinterfaces.RegisterClientUserInterface;
import utilitis.EnviaromentProperties;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;

public class RegisterClientStepDefinition {

    private String URL;

    @Before
    public void getConfiguration(){

        OnStage.setTheStage(new OnlineCast());
        URL = EnviaromentProperties.getProperty("url_prueba");

    }

    @Given("El usuario ingresa a la pagina web")
    public void Elusuarioingresaalapaginaweb(){

        OnStage.theActorCalled("Juan Pablo").attemptsTo(Open.url(URL));

    }

    @When("^El usuario registra el cliente nuevo$")
    public void elUsuarioRegistraElClienteNuevoCountryCity(DataTable data) {

        OnStage.theActorCalled("Juan Pablo").attemptsTo(IncomeNewAccount.incomeNewAccount());
        OnStage.theActorCalled("Juan Pablo").attemptsTo(CreateAccount.createAccount(data.asLists().get(0)));

    }

    @Then("El usuario valida el registro exitoso")
    public void elUsuarioValidaElRegistroExitoso() {

        OnStage.theActorInTheSpotlight().should(seeThat(ValidateAccount.visibles(RegisterClientUserInterface.VALIDATE_CREATE_ACCOUNT),
                equalTo(theActorInTheSpotlight().recall(KeysRegisterClient.KEY1.value()))));

    }


}
